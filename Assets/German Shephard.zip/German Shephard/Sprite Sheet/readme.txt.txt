Sprite sheet order (top to bottom):

1. Idle Blink
2. Idle
3. Walk
4. Run
5. Sniff
6. Track
7. Bark
8. Bite
9. Death

